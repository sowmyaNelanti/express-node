var http = require('http');
var express = require('express');
var exp = express();
var parser=require('body-parser')
var fs = require('fs');
var cors = require('cors');
//var mongodb = require('mongodb').MongoClient;



exp.route('/rest/api/get').get((req, res)=>{
    
   
    var data = JSON.parse(fs.readFileSync('prob3.json'));
 
             res.status(201).send(data);
             console.log(data);
})

exp.use(cors()).listen(4000, ()=>console.log("RUNNING...."));