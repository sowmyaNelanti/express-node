var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var dbo = db.db("prodb");
  var productList = [
    { productId: '1', productName: 'pizza',productCost:300, productDes:'Tasty'},
    { productId: '2', productName: 'Burger',productCost:200, productDes:'good'},
    { productId: '3', productName: 'GarlicBread',productCost:80, productDes:'Ok'},
    { productId: '4', productName: 'Momos',productCost:100, productDes:'bad'}
   
  ];
  dbo.collection("products").insertMany(productList, function(err, res) {
    if (err) throw err;
    else{
    console.log("Number of documents inserted: " + res.insertedCount);
      console.log("Database created!");
    }
    db.close();
  });
});